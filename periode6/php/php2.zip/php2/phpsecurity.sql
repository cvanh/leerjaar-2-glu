
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `postdata` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
